package com.company;
import java.sql.*;
public class insertOrderInfo
{
    String connectionUrl="jdbc:postgresql://localhost:5432/postgres";
    Connection con;
    ResultSet insert;
    Statement stmt ;
    public insertOrderInfo(int id,String describe,int amountWeb,int amountDesign,int amountApp,int amountVr){
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl,"postgres","1234");
            stmt = con.createStatement();
            insert = stmt.executeQuery("insert into std(id,describe ,amountWeb,amountDesign,amountApp,amountVr) values(" + id + ",'" + describe + "','" + amountWeb + "','" + amountDesign + "','" + amountApp + "','" + amountVr + "')");
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            //e.printStackTrace();
        }
    }
}
