package com.company;
import java.sql.*;
public class cost extends staffs //cost class extends staffs class, in order to use web, design, app, vr classes
{
    String connectionUrl="jdbc:postgresql://localhost:5432/postgres";
    Connection con;
    ResultSet insert;
    Statement stmt ;
    public cost(int id){
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl,"postgres","1234");
            stmt = con.createStatement();
            insert = stmt.executeQuery("select * from std where id = " + id);
            while(insert.next())
            {

            int costWeb = (insert.getInt("amountWeb"))*web; //the salary for one employee is equal to web and in order to calculate the overall salary we will multiply
            int costDesigner =(insert.getInt("amountDesign"))*design;
            int costApp = (insert.getInt("amountApp"))*app;
            int costVr =(insert.getInt("amountVr"))*vr;
            System.out.println("overall :"+(costApp+costVr+costDesigner+costWeb+"$"));//in order to show the overall salary
            System.out.println();
            }
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        try
        {
            insert.close();
            stmt.close();
            con.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}