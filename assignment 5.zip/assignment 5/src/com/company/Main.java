package com.company;

import java.util.Scanner;
public class Main extends staffs {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Main m = new Main();
        boolean menu = true;int id=0;
        System.out.println("First, check out our team and services");
        while (menu) {
            id+=1;
            System.out.println("1.View developers information");
            System.out.println("2.To order the project");
            System.out.println("3.To quit");
            int choice = input.nextInt();
            switch (choice) {
                case 1:
                    m.aboutStaff();
                    System.out.println(" ");
                    break;

                case 2:
                    m.orderMethod(id);
                    break;

                case 3:
                    menu = false;
                    break;
                default:
                    System.out.println("Please, print number have in menu\n");
                    break;
            }
        }
        System.out.print("Bye,bye!\n");
    }




    public void orderMethod(int id){
        Scanner input = new Scanner(System.in);
        System.out.println("\nYou choose order part\nProject's theme:");
        String ordersTheme = input.nextLine();
        System.out.println("\nHow many web developers do you need?");
        int amountWeb = input.nextInt();
        System.out.println("\nHow many designers do you need?");
        int amountDesign = input.nextInt();
        System.out.println("\nHow many app developers do you need?");
        int amountApp = input.nextInt();
        System.out.println("\nHow many vr developers do you need?");
        int amountVr = input.nextInt();
        insertOrderInfo insertt = new insertOrderInfo(id,ordersTheme,amountWeb,amountDesign,amountApp,amountVr);
        System.out.println(" ");
        cost salary = new cost(id);
    }

    public void aboutStaff(){
        System.out.println("What we can develop:\n1.Web development: salary "+web+"$\n2.Web designing: salary "+design+"$\n3.App developer: salary "+app+"$\n4.vr developer: salary "+vr+"$" );
    }

    }

