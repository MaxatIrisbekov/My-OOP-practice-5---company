package com.company;
import java.sql.*;
public class staffs
{ int web,app,design,vr;//the firstly we initialized the variables

    String connectionUrl="jdbc:postgresql://localhost:5432/postgres";
    Connection con;
    ResultSet insert;
    Statement stmt ;
    public staffs(){
        int id =1;
        try
        {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl,"postgres","1234");
            stmt = con.createStatement();
            insert = stmt.executeQuery("select * from staff where id = " + id);
            while(insert.next())
            {
                web =insert.getInt("webStaff");
                design = insert.getInt("designStaff");
                app=insert.getInt("appStaff");
                vr=insert.getInt("vrStaff");
            }
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        try
        {
            insert.close();
            stmt.close();
            con.close();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }
}